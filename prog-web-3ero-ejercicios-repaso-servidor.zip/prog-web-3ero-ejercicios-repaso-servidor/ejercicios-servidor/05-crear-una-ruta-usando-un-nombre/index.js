const express = require('express');
const app = express();

app.get('/', (_, res) => {
  res.send("Hola mundo");
});

app.get('/:nombre', (req, res) => {
  const nombre = req.params.nombre;
  res.send(`Tu nombre es ${nombre}`);
});

app.listen(3000); 